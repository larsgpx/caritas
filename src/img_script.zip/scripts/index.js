import '../styles/index.scss';
(function($) {
    "use strict"; // Start of use strict

    // Smooth scrolling using jQuery easing
    $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: (target.offset().top - 72)
                }, 1000, "easeInOutExpo");
                return false;
            }
        }
    });


    // cambiar textos en banner
    var text = ["Hola, <br> Cambiamos", "Descubre el <br> nuevo Elemental", "Expertos en <br> Comunicación Digital"];
    var counter = 0;
    var elem = document.getElementById("changeText");
    var inst = setInterval(change, 3000);

    function change() {
    elem.innerHTML = text[counter];
    counter++;
    if (counter >= text.length) {
        counter = 0;
        // clearInterval(inst); // descomentar en caso de que se queira detener al terminar el primer ciclo
    }
    }
    //change color in about section
    $("#v-pills-home-tab").hover(function() {
        $('.color-bg').css("background-color", "#0851e9");
    });
    $("#v-pills-profile-tab").hover(function() {
        $('.color-bg').css("background-color", "#ff5922");
    });
    $("#v-pills-messages-tab").hover(function() {
        $('.color-bg').css("background-color", "#ffbf00");
    });
    $("#v-pills-settings-tab").hover(function() {
        $('.color-bg').css("background-color", "#00dea8");
    });

    // animacion en services section
    $('.collapse').collapse();


    $('#branding').click(function() {
        $('.default-content').animate({
            opacity: 0.25,
            left: "+=50",
            height: "toggle"
        }, 500, function() {
            $('.select-content-list').fadeIn();
            $('#default-bg').addClass('list-img-services');
            $('#collapseOne').addClass('show');
            $('#default-bg').css('background-image', 'url(src/img/branding-large.png)');
        });

    });

    $('#marketing-digital').click(function() {
        $('.default-content').animate({
            opacity: 0.25,
            left: "+=50",
            height: "toggle"
        }, 500, function() {
            $('.select-content-list').fadeIn();
            $('#default-bg').addClass('list-img-services');
            $('#collapseOne').removeClass('show');
            $('#headingOne h3 .btn').attr('aria-expanded', false);
            $('#headingTwo h3 .btn').attr('aria-expanded', true);
            $('#collapseTwo').addClass('show');
            $('#default-bg').css('background-image', 'url(src/img/marketing-large.png)');
        });

    });

    $('#diseno-web').click(function() {
        $('.default-content').animate({
            opacity: 0.25,
            left: "+=50",
            height: "toggle"
        }, 500, function() {
            $('.select-content-list').fadeIn();
            $('#default-bg').addClass('list-img-services');
            $('#collapseOne').removeClass('show');
            $('#headingOne h3 .btn').attr('aria-expanded', false);
            $('#headingThree h3 .btn').attr('aria-expanded', true);
            $('#collapseThree').addClass('show');
            $('#default-bg').css('background-image', 'url(src/img/web-large.png)');
        });

    });

    $('#audiovisual').click(function() {
        $('.default-content').animate({
            opacity: 0.25,
            left: "+=50",
            height: "toggle"
        }, 500, function() {
            $('.select-content-list').fadeIn();
            $('#default-bg').addClass('list-img-services');
            $('#collapseOne').removeClass('show');
            $('#headingOne h3 .btn').attr('aria-expanded', false);
            $('#headingFour h3 .btn').attr('aria-expanded', true);
            $('#collapseFour').addClass('show');
            $('#default-bg').hide();
            $('#video-bg').fadeIn();
        });

    });

    // change image services
    $('#headingOne').click(function() {
        $('#default-bg').fadeIn();
        $('#default-bg').css('background-image', 'url(src/img/branding-large.png)');
        $('#video-bg').hide();
    });
    $('#headingTwo').click(function() {
        $('#default-bg').fadeIn();
        $('#default-bg').css('background-image', 'url(src/img/marketing-large.png)');
        $('#video-bg').hide();
    });
    $('#headingThree').click(function() {
        $('#default-bg').fadeIn();
        $('#default-bg').css('background-image', 'url(src/img/web-large.png)');
        $('#video-bg').hide();
    });
    $('#headingFour').click(function() {
        $('#default-bg').hide();
        $('#video-bg').fadeIn();
    });


    // Closes responsive menu when a scroll trigger link is clicked
    $('.js-scroll-trigger').click(function() {
        $('.navbar-collapse').collapse('hide');
    });

    // Activate scrollspy to add active class to navbar items on scroll
    $('body').scrollspy({
        target: '#mainNav',
        offset: 75
    });

    // Collapse Navbar
    var navbarCollapse = function() {
        if ($("#mainNav").offset().top > 100) {
            $("#mainNav").addClass("navbar-scrolled");
        } else {
            $("#mainNav").removeClass("navbar-scrolled");
        }
    };
    // Collapse now if page is not at top
    navbarCollapse();
    // Collapse the navbar when page is scrolled
    $(window).scroll(navbarCollapse);

    // Magnific popup calls
    $('#portfolio').magnificPopup({
        delegate: 'a',
        type: 'image',
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0, 1]
        },
        image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
        }
    });

})(jQuery); // End of use strict